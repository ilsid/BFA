//>>built
define("dijit/nls/hu/loading",({loadingState:"Betöltés...",errorState:"Sajnálom, hiba történt"}));
