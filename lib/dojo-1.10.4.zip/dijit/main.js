//>>built
define("dijit/main",["dojo/_base/kernel"],function(_1){
return _1.dijit;
});
