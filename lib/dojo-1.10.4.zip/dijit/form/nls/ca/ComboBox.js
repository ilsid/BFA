//>>built
define("dijit/form/nls/ca/ComboBox",({previousMessage:"Opcions anteriors",nextMessage:"Més opcions"}));
